import React, { useEffect } from 'react'
import { useLocation, useNavigate, useParams, Link } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { Row, Col, Image, ListGroup, Button, Card, Container, Form } from 'react-bootstrap'
import { addToCart, removeFromCart } from '../actions/cartActions'

const formatPrice = (price) => (price != null ? Number(price).toFixed(2) : '0.00')

export default function CartScreen() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const location = useLocation()
  const { id } = useParams()

  const cart = useSelector((state) => state.cart)
  const { cartItems } = cart

  useEffect(() => {
    if (id) {
      dispatch(addToCart(id, location.search ? Number(location.search.split('=')[1]) : 1))
    }
  }, [dispatch, id, location.search])

  const cartScreenHandler = (productId, qty) => {
    dispatch(addToCart(productId, Number(qty)))
  }

  const removeFromCartHandler = (productId) => {
    dispatch(removeFromCart(productId))
  }

  const checkoutHandler = () => {
    if (!cartItems.length) {
      return
    }
    navigate('/shipping')
  }

  return (
    <>
      <Link to="/" className="btn btn-secondary">
        Back
      </Link>
      <Container>
        {cartItems.length === 0 ? (
          <div>Your cart is empty <Link to="/">Go Back</Link></div>
        ) : (
          <>
            <Row start="xs">
              <Col md={8}>
                <h2>Cart</h2>
                <ListGroup variant="flush">
                  {cartItems.map((item) => (
                    <ListGroup.Item key={item.product}>
                      <Row>
                        <Col md={2}>
                          <Image src={item.image || '/static/images/placeholder.jpg'} fluid />
                        </Col>
                        <Col md={3}>
                          <Link to={`/product/${item.product}`}>
                            {item.name}
                          </Link>
                        </Col>
                        <Col md={2}>
                          <span>Rs {formatPrice(item.price)}</span>
                        </Col>
                        <Col md={2}>
                          <Form.Control
                            as="select"
                            value={item.qty}
                            onChange={(e) =>
                              cartScreenHandler(item.product, e.target.value)
                            }
                          >
                            {[...Array(item.countInStock).keys()].map((x) => (
                              <option key={x + 1} value={x + 1}>
                                {x + 1}
                              </option>
                            ))}
                          </Form.Control>
                        </Col>
                        <Col md={3}>
                          <Button
                            size="sm"
                            secondary
                            onClick={() => removeFromCartHandler(item.product)}
                          >
                            🗑 Delete
                          </Button>
                        </Col>
                      </Row>
                    </ListGroup.Item>
                  ))}
                </ListGroup>
              </Col>
              <Col md={4}>
                <Card>
                  <ListGroup variant="flush">
                    <ListGroup.Item>
                      <h2>Order Summary</h2>
                    </ListGroup.Item>
                    <ListGroup.Item className="d-flex justify-content-between">
                      <span>Items</span>
                      <span>{cartItems.reduce((a, c) => a + c.qty, 0)}</span>
                    </ListGroup.Item>
                    <ListGroup.Item className="d-flex justify-content-between">
                      <span>Shipping</span>
                      <span>Rs {formatPrice(cartItems.reduce((a, c) => a + c.price * c.qty, 0) * 0.1)}</span>
                    </ListGroup.Item>
                    <ListGroup.Item className="d-flex justify-content-between">
                      <span>Tax</span>
                      <span>Rs {formatPrice(cartItems.reduce((a, c) => a + c.price * c.qty, 0) * 0.2)}</span>
                    </ListGroup.Item>
                    <ListGroup.Item className="d-flex justify-content-between">
                      <span>Order Total</span>
                      <span>
                        Rs {formatPrice(cartItems.reduce((a, c) => a + c.price * c.qty, 0) * 1.3)}
                      </span>
                    </ListGroup.Item>
                    <ListGroup.Item>
                      <Button
                        className="w-100"
                        primary
                        disabled={!cartItems.length}
                        onClick={checkoutHandler}
                      >
                        Proceed to Checkout
                      </Button>
                    </ListGroup.Item>
                  </ListGroup>
                </Card>
              </Col>
            </Row>
          </>
        )}
      </Container>
    </>
  )
}