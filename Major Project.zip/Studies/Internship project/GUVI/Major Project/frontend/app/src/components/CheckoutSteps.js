import { useSelector } from 'react-redux'

export default function CheckoutSteps({ step1, step2, step3, step4 }) {
  const { userInfo } = useSelector((state) => state.userLogin)
  const { shippingAddress } = useSelector((state) => state.cart)
  const { paymentMethod } = useSelector((state) => state.cart)
  const { order } = useSelector((state) => state.orderCreate)

  return (
    <div className="mt-3">
      <div className="d-flex flex-nowrap stepper">
        {step1 && (
          <div className={`step ${step1}`}>{step1}</div>
        )}
        {step2 && (
          <div className={`step ${step2}`}>{step2}</div>
        )}
        {step3 && (
          <div className={`step ${step3}`}>{step3}</div>
        )}
        {step4 && (
          <div className={`step ${step4}`}>{step4}</div>
        )}
      </div>
    </div>
  )
}