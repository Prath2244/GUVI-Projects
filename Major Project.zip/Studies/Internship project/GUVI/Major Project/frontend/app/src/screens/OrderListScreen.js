import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { listOrders, deleteOrder } from '../actions/orderActions'
import Loader from '../components/Loader'
import Message from '../components/Message'
import { Button, Table } from 'react-bootstrap'

export default function OrderListScreen() {
  const dispatch = useDispatch()
  const orderList = useSelector((state) => state.orderList)
  const { loading, error, orders } = orderList

  const orderDelete = useSelector((state) => state.orderDelete)
  const { success: deleteSuccess, error: deleteError } = orderDelete

  useEffect(() => {
    dispatch(listOrders())
  }, [dispatch])

  const deleteHandler = (id) => {
    if (window.confirm('Are you sure?')) {
      dispatch(deleteOrder(id))
    }
  }

  return (
    <>
      {deleteSuccess && (
        <Message variant="success">Order deleted.</Message>
      )}
      {deleteError && <Message variant="danger">{deleteError}</Message>}
      {loading ? (
        <Loader />
      ) : (
        <Table>
          <thead>
            <tr>
              <th>Order ID</th>
              <th>User</th>
              <th>Total</th>
              <th>Paid</th>
              <th>Delivered</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id}>
                <td>{order.id}</td>
                <td>{order.user}</td>
                <td>{order.total_price}</td>
                <td>{order.is_paid ? 'Yes' : 'No'}</td>
                <td>{order.is_delivered ? 'Yes' : 'No'}</td>
                <td>
                  <Button variant="danger" onClick={() => deleteHandler(order.id)}>
                    Delete
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </>
  )
}