import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { Row, Col, Card, Form, Button } from 'react-bootstrap'
import { savePaymentMethod } from '../actions/cartActions'
import Loader from '../components/Loader'
import Message from '../components/Message'

export default function PaymentScreen() {
  const dispatch = useDispatch()
  const navigate = useNavigate()

  const cart = useSelector((state) => state.cart)
  const { paymentMethod, shippingAddress } = cart

  const [payment, setPayment] = useState(paymentMethod || 'Cash on Delivery')

  const submitHandler = (e) => {
    e.preventDefault()
    dispatch(savePaymentMethod(payment))
    navigate('/placeorder')
  }

  return (
    <>
      <Row start="xs">
        <Col md={6} className="m-4">
          <Card>
            <Card.Body className="text-center">
              <h3>Payment Method</h3>
            </Card.Body>
            <Card.Body>
              <Form onSubmit={submitHandler}>
                <Form.Group>
                  <Form.Label>Select Payment Method</Form.Label>
                  <Form.Control
                    as="select"
                    value={payment}
                    onChange={(e) => setPayment(e.target.value)}
                    required
                  >
                    <option value="Cash on Delivery">Cash on Delivery</option>
                    <option value="PayPal">PayPal</option>
                  </Form.Control>
                </Form.Group>
                <Button className="w-100" primary type="submit">
                  Continue
                </Button>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </>
  )
}