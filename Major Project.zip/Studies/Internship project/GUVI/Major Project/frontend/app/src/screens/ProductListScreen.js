import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { listProducts, deleteProduct, createProduct } from '../actions/productActions'
import Loader from '../components/Loader'
import Message from '../components/Message'
import { Button, Table, Card } from 'react-bootstrap'

export default function ProductListScreen() {
  const dispatch = useDispatch()
  const productList = useSelector((state) => state.productList)
  const { loading, error, products } = productList
  const productCreate = useSelector((state) => state.productCreate)
  const productDelete = useSelector((state) => state.productDelete)

  const { success: createSuccess, error: createError } = productCreate
  const { success: deleteSuccess, error: deleteError } = productDelete

  useEffect(() => {
    dispatch(listProducts())
  }, [dispatch])

  const deleteHandler = (id) => {
    if (window.confirm('Are you sure?')) {
      dispatch(deleteProduct(id))
    }
  }

  const createProductHandler = () => {
    dispatch(createProduct())
  }

  return (
    <>
      <Card>
        <Button block={true} primary onClick={createProductHandler}>
          Create Product
        </Button>
      </Card>
      {createSuccess && (
        <Message variant="success">Product created. Redirecting...</Message>
      )}
      {createError && <Message variant="danger">{createError}</Message>}
      {deleteSuccess && <Message variant="success">Product deleted.</Message>}
      {deleteError && <Message variant="danger">{deleteError}</Message>}
      {loading ? (
        <Loader />
      ) : (
        <Table>
          <thead>
            <tr>
              <th>Image</th>
              <th>Name</th>
              <th>Price</th>
              <th>Category</th>
              <th>Brand</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.id}>
                <td>
                  <img src={product.image || '/static/images/placeholder.jpg'} width="100" alt={product.name} />
                </td>
                <td>{product.name}</td>
                <td>{product.price}</td>
                <td>{product.category}</td>
                <td>{product.brand}</td>
                <td>
                  <Button
                    variant="warning"
                    onClick={() => window.location.href = `/admin/productedit/${product.id}`}
                  >
                    Edit
                  </Button>{' '}
                  <Button variant="danger" onClick={() => deleteHandler(product.id)}>
                    Delete
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </>
  )
}