import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { Row, Col, Form, Button, Card } from 'react-bootstrap'
import { saveShippingAddress } from '../actions/cartActions'
import Loader from '../components/Loader'
import Message from '../components/Message'

export default function ShippingScreen() {
  const dispatch = useDispatch()
  const navigate = useNavigate()

  const { cart } = useSelector((state) => state)
  const { shippingAddress } = cart

  const [formData, setFormData] = useState({
    address: shippingAddress.address || '',
    city: shippingAddress.city || '',
    postalCode: shippingAddress.postal_code || '',
    country: shippingAddress.country || '',
  })

  const submitHandler = (e) => {
    e.preventDefault()
    dispatch(saveShippingAddress(formData))
    navigate('/payment')
  }

  return (
    <>
      <Row start="xs">
        <Col md={6} className="m-4">
          <Card>
            <Card.Body className="text-center">
              <h3>Shipping Address</h3>
            </Card.Body>
            <Card.Body>
              <Form onSubmit={submitHandler}>
                <Form.Group>
                  <Form.Label>Address</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Address"
                    name="address"
                    value={formData.address}
                    onChange={(e) =>
                      setFormData({ ...formData, [e.target.name]: e.target.value })
                    }
                    required
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>City</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="City"
                    name="city"
                    value={formData.city}
                    onChange={(e) =>
                      setFormData({ ...formData, [e.target.name]: e.target.value })
                    }
                    required
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Postal Code</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Postal Code"
                    name="postalCode"
                    value={formData.postalCode}
                    onChange={(e) =>
                      setFormData({ ...formData, [e.target.name]: e.target.value })
                    }
                    required
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Country</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Country"
                    name="country"
                    value={formData.country}
                    onChange={(e) =>
                      setFormData({ ...formData, [e.target.name]: e.target.value })
                    }
                    required
                  />
                </Form.Group>
                <Button className="w-100" primary type="submit">
                  Continue
                </Button>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </>
  )
}