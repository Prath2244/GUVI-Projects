import React, { useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { getOrderDetails } from '../actions/orderActions'
import Loader from '../components/Loader'
import Message from '../components/Message'

const formatPrice = (price) => (price != null ? Number(price).toFixed(2) : '0.00')

export default function OrderScreen() {
  const dispatch = useDispatch()
  const { id } = useParams()

  const orderDetails = useSelector((state) => state.orderDetails)
  const { loading, error, order } = orderDetails

  useEffect(() => {
    dispatch(getOrderDetails(id))
  }, [dispatch, id])

  return (
    <>
      {loading ? (
        <Loader />
      ) : error ? (
        <Message variant="danger">{error}</Message>
      ) : (
        <>
          <h2>Order {order.id}</h2>
          <p>Status: {order.is_paid ? 'Paid' : 'Not Paid'}</p>
          <p>Delivered: {order.is_delivered ? 'Yes' : 'No'}</p>
          <p>Total: Rs {formatPrice(order.total_price)}</p>
        </>
      )}
    </>
  )
}