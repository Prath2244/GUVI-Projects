import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { Row, Col, Form, Button, Card, InputGroup } from 'react-bootstrap'
import { register } from '../actions/userActions'
import Loader from '../components/Loader'
import Message from '../components/Message'

export default function SignupScreen() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
  })
  const [show, setShow] = useState(false)

  const dispatch = useDispatch()
  const navigate = useNavigate()

  const userRegister = useSelector((state) => state.userRegister)
  const { loading, error } = userRegister

  const submitHandler = (e) => {
    e.preventDefault()
    dispatch(
      register(
        formData.firstName,
        formData.lastName,
        formData.email,
        formData.password
      )
    )
  }

  const showPassword = () => {
    setShow(!show)
  }

  return (
    <>
      {loading ? (
        <Loader />
      ) : error ? (
        <Message variant="danger">{error}</Message>
      ) : null}
      <Row start="xs">
        <Col md={6} className="m-4">
          <Card>
            <Card.Body className="text-center">
              <h3>Register</h3>
            </Card.Body>
            <Card.Body>
              <Form onSubmit={submitHandler}>
                <Form.Group>
                  <Form.Label>First Name</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter your first name"
                    name="firstName"
                    value={formData.firstName}
                    onChange={(e) =>
                      setFormData({ ...formData, [e.target.name]: e.target.value })
                    }
                    required
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Last Name</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter your last name"
                    name="lastName"
                    value={formData.lastName}
                    onChange={(e) =>
                      setFormData({ ...formData, [e.target.name]: e.target.value })
                    }
                    required
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Email</Form.Label>
                  <Form.Control
                    type="email"
                    placeholder="Enter your email"
                    name="email"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({ ...formData, [e.target.name]: e.target.value })
                    }
                    required
                  />
                </Form.Group>
                <Form.Group>
                  <InputGroup>
                    <InputGroup.Text>
                      <i
                        className={`fa ${show ? 'fa-eye-slash' : 'fa-eye'}`}
                        onClick={showPassword}
                      />
                    </InputGroup.Text>
                    <Form.Control
                      type={show ? 'text' : 'password'}
                      placeholder="Enter your password"
                      name="password"
                      value={formData.password}
                      onChange={(e) =>
                        setFormData({ ...formData, [e.target.name]: e.target.value })
                      }
                      required
                    />
                  </InputGroup>
                </Form.Group>
                <Form.Group>
                  <InputGroup>
                    <InputGroup.Text>
                      <i
                        className={`fa ${show ? 'fa-eye-slash' : 'fa-eye'}`}
                        onClick={showPassword}
                      />
                    </InputGroup.Text>
                    <Form.Control
                      type={show ? 'text' : 'password'}
                      placeholder="Confirm your password"
                      name="confirmPassword"
                      value={formData.confirmPassword}
                      onChange={(e) =>
                        setFormData({ ...formData, [e.target.name]: e.target.value })
                      }
                      required
                    />
                  </InputGroup>
                </Form.Group>
                <Button className="w-100" primary type="submit">
                  Register
                </Button>
              </Form>
            </Card.Body>
            <Card.Body className="text-center">
              {'Already have an account? '}
              <a href="/login">Login</a>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </>
  )
}