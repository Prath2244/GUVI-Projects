import React from 'react'
import { Alert } from 'react-bootstrap'

export default function Message({ variant, children, dismissible, autoDismiss, timeout }) {
  const [show, setShow] = React.useState(true)

  React.useEffect(() => {
    if (autoDismiss) {
      const timer = setTimeout(() => setShow(false), timeout || 15000)
      return () => clearTimeout(timer)
    }
  }, [autoDismiss, timeout])

  const handleClose = () => setShow(false)

  return (
    <>
      {show && (
        <Alert variant={variant} dismissible={dismissible} onClose={handleClose}>
          {children}
        </Alert>
      )}
    </>
  )
}