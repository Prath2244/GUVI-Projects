import React, { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { listProductDetails, updateProduct, productUpdateReset } from '../actions/productActions'
import Loader from '../components/Loader'
import Message from '../components/Message'
import { Button, Form, Card } from 'react-bootstrap'

export default function ProductEditScreen() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const { id } = useParams()

  const [formData, setFormData] = useState({
    name: '',
    price: '',
    image: '',
    brand: '',
    category: '',
    countInStock: '',
    description: '',
  })
  const [uploading, setUploading] = useState(false)

  const productDetails = useSelector((state) => state.productDetails)
  const { loading, error, product } = productDetails
  const productUpdate = useSelector((state) => state.productUpdate)

  const { success, error: updateError } = productUpdate

  useEffect(() => {
    if (!product || product.id !== id) {
      dispatch(listProductDetails(id))
    }

    if (success) {
      navigate('/admin/productlist')
    }

    return () => {
      dispatch(productUpdateReset())
    }
  }, [dispatch, navigate, product, success, id])

  useEffect(() => {
    if (product) {
      setFormData({
        name: product.name,
        price: product.price,
        image: product.image,
        brand: product.brand,
        category: product.category,
        countInStock: product.count_in_stock,
        description: product.description,
      })
    }
  }, [product])

  const submitHandler = (e) => {
    e.preventDefault()
    dispatch(updateProduct({ ...formData, _id: id }))
  }

  const uploadFileHandler = (e) => {
    setUploading(true)
    const formData = new FormData()
    formData.append('image', e.target.files[0])
    formData.append('product_id', id)

    // uploadImage API call would go here
    setUploading(false)
  }

  return (
    <>
      {loading ? (
        <Loader />
      ) : error ? (
        <Message variant="danger">{error}</Message>
      ) : updateError ? (
        <Message variant="danger">{updateError}</Message>
      ) : (
        <>
          <Card>
            <Button onClick={() => navigate('/admin/productlist')}>
              Back
            </Button>
            <Form onSubmit={submitHandler}>
              <Form.Group>
                <Form.Label>Name</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter product name"
                  name="name"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, [e.target.name]: e.target.value })
                  }
                  required
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>Price</Form.Label>
                <Form.Control
                  type="number"
                  placeholder="Enter product price"
                  name="price"
                  value={formData.price}
                  onChange={(e) =>
                    setFormData({ ...formData, [e.target.name]: e.target.value })
                  }
                  required
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>Image URL</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter product image URL"
                  name="image"
                  value={formData.image}
                  onChange={(e) =>
                    setFormData({ ...formData, [e.target.name]: e.target.value })
                  }
                  required
                />
                <input type="file" onChange={uploadFileHandler} />
              </Form.Group>
              <Form.Group>
                <Form.Label>Brand</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter product brand"
                  name="brand"
                  value={formData.brand}
                  onChange={(e) =>
                    setFormData({ ...formData, [e.target.name]: e.target.value })
                  }
                  required
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>Category</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter product category"
                  name="category"
                  value={formData.category}
                  onChange={(e) =>
                    setFormData({ ...formData, [e.target.name]: e.target.value })
                  }
                  required
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>Count In Stock</Form.Label>
                <Form.Control
                  type="number"
                  placeholder="Enter product stock count"
                  name="countInStock"
                  value={formData.countInStock}
                  onChange={(e) =>
                    setFormData({ ...formData, [e.target.name]: e.target.value })
                  }
                  required
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>Description</Form.Label>
                <Form.Control
                  as="textarea"
                  placeholder="Enter product description"
                  name="description"
                  value={formData.description}
                  onChange={(e) =>
                    setFormData({ ...formData, [e.target.name]: e.target.value })
                  }
                  required
                />
              </Form.Group>
              <Button type="submit">Update Product</Button>
            </Form>
          </Card>
        </>
      )}
    </>
  )
}