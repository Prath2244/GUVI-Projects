import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link, useNavigate } from 'react-router-dom'
import { Row, Col, Image, ListGroup, Card, Button } from 'react-bootstrap'
import { listProducts } from '../actions/productActions'
import Loader from '../components/Loader'
import Message from '../components/Message'

const formatPrice = (price) => (price != null ? Number(price).toFixed(2) : '0.00')

export default function HomeScreen() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const productList = useSelector((state) => state.productList)
  const { loading, error, products } = productList

  useEffect(() => {
    dispatch(listProducts())
  }, [dispatch])

  return (
    <>
      {loading ? (
        <Loader />
      ) : error ? (
        <Message variant="danger">{error}</Message>
      ) : (
        <Row center xs={1} sm={2} md={3} lg={4} className="mb-3">
          {products.map((product) => (
            <Col key={product.id}>
              <Link to={`/product/${product.id}`}>
                <Card>
                  <Card.Img
                    variant="top"
                    src={product.image || '/static/images/placeholder.jpg'}
                  />
                  <Card.Body>
                    <Card.Title>{product.name}</Card.Title>
                    <ListGroup.Item>
                      {product.rating} <i className="fa fa-star" /> {product.num_reviews} reviews
                    </ListGroup.Item>
                    <Card.Text>
                      <strong>Rs {formatPrice(product.price)}</strong>
                    </Card.Text>
                  </Card.Body>
                  <Card.Body>
                    <Button
                      className="w-100"
                      primary
                      onClick={() => navigate(`/product/${product.id}`)}
                    >
                      Details
                    </Button>
                  </Card.Body>
                </Card>
              </Link>
            </Col>
          ))}
        </Row>
      )}
    </>
  )
}