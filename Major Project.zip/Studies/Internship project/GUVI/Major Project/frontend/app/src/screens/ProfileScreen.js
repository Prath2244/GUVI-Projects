import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Table, Card, Button, ListGroup } from 'react-bootstrap'
import { listMyOrders } from '../actions/orderActions'
import Loader from '../components/Loader'
import Message from '../components/Message'

const formatPrice = (price) => (price != null ? Number(price).toFixed(2) : '0.00')

export default function ProfileScreen() {
  const dispatch = useDispatch()
  const userLogin = useSelector((state) => state.userLogin)
  const { userInfo } = userLogin
  const orderListMy = useSelector((state) => state.orderListMy)
  const { loading, error, orders } = orderListMy

  useEffect(() => {
    dispatch(listMyOrders())
  }, [dispatch])

  return (
    <>
      {loading ? (
        <Loader />
      ) : error ? (
        <Message variant="danger">{error}</Message>
      ) : (
        <>
          <h2>User Profile</h2>
          <Card>
            <ListGroup variant="flush">
              <ListGroup.Item>
                <h3>Name: {userInfo?.name}</h3>
              </ListGroup.Item>
              <ListGroup.Item>
                <strong>Email:</strong> {userInfo?.email}
              </ListGroup.Item>
            </ListGroup>
          </Card>
          <h3>Order History</h3>
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Date</th>
                <th>Total</th>
                <th>Paid</th>
                <th>Delivered</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => (
                <tr key={order.id}>
                  <td>{order.id}</td>
                  <td>{order.created_at}</td>
                  <td>Rs {formatPrice(order.total_price)}</td>
                  <td>{order.is_paid ? 'Yes' : 'No'}</td>
                  <td>{order.is_delivered ? 'Yes' : 'No'}</td>
                </tr>
              ))}
            </tbody>
          </Table>
        </>
      )}
    </>
  )
}