import React, { useEffect } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { Row, Col, Image, ListGroup, Card, Button, Form } from 'react-bootstrap'
import { listProductDetails } from '../actions/productActions'
import { addToCart } from '../actions/cartActions'
import Loader from '../components/Loader'
import Message from '../components/Message'

const formatPrice = (price) => (price != null ? Number(price).toFixed(2) : '0.00')

export default function ProductScreen() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const { id } = useParams()
  const productDetails = useSelector((state) => state.productDetails)
  const { loading, error, product } = productDetails
  const cart = useSelector((state) => state.cart)
  const { cartItems } = cart

  useEffect(() => {
    dispatch(listProductDetails(id))
  }, [dispatch, id])

  const addToCartHandler = () => {
    dispatch(addToCart(id, 1))
    navigate('/cart')
  }

  return (
    <>
      {loading ? (
        <Loader />
      ) : error ? (
        <Message variant="danger">{error}</Message>
      ) : (
        <>
          <Link to="/" className="btn btn-secondary">
            Back
          </Link>
          <Row className="mt-3">
            <Col md={6}>
              <Image src={product.image || '/static/images/placeholder.jpg'} fluid rounded />
            </Col>
            <Col md={3}>
              <ListGroup variant="flush">
                <ListGroup.Item>
                  <h1>{product.name}</h1>
                </ListGroup.Item>
                <ListGroup.Item>
                  <strong>Brand:</strong> {product.brand}
                </ListGroup.Item>
                <ListGroup.Item>
                  <strong>Category:</strong> {product.category}
                </ListGroup.Item>
                <ListGroup.Item>
                  <strong>Price:</strong> Rs {formatPrice(product.price)}
                </ListGroup.Item>
                <ListGroup.Item>
                  <strong>Description:</strong>
                  <p>{product.description}</p>
                </ListGroup.Item>
                <ListGroup.Item>
                  <div className="d-flex justify-content-between align-items-center">
                    <strong>Availability:</strong>
                    {product.count_in_stock > 0 ? (
                      <span className="badge bg-success p-2">In Stock</span>
                    ) : (
                      <span className="badge bg-danger p-2">Out of Stock</span>
                    )}
                  </div>
                </ListGroup.Item>
                <ListGroup.Item>
                  <strong>Seller:</strong> {'<same>'}
                </ListGroup.Item>
                <ListGroup.Item>
                  <strong>Rating:</strong> {product.rating} &nbsp;<i className="fa fa-star"></i>
                </ListGroup.Item>
                <ListGroup.Item>
                  <strong>Num Reviews:</strong> {product.num_reviews}
                </ListGroup.Item>
              </ListGroup>
            </Col>
            <Col md={3}>
              <Card>
                <ListGroup variant="flush">
                  <ListGroup.Item>
                    <h2>Rs {formatPrice(product.price)}</h2>
                  </ListGroup.Item>
                  <ListGroup.Item>
                    Status:{' '}
                    {product.count_in_stock > 0 ? (
                      <span className="badge bg-success p-2">In Stock</span>
                    ) : (
                      <span className="badge bg-danger p-2">Out of Stock</span>
                    )}
                  </ListGroup.Item>
                  <ListGroup.Item>
                    <Form>
                      <Form.Group>
                        <Form.Label>Quantity</Form.Label>
                        <Form.Control as="select">
                          {[...Array(product.count_in_stock).keys()].map((x) => (
                            <option key={x + 1} value={x + 1}>
                              {x + 1}
                            </option>
                          ))}
                        </Form.Control>
                      </Form.Group>
                    </Form>
                  </ListGroup.Item>
                  <ListGroup.Item>
                    <Button
                      block={true}
                      disabled={product.count_in_stock === 0}
                      primary
                      onClick={addToCartHandler}
                    >
                      Add to Cart
                    </Button>
                  </ListGroup.Item>
                </ListGroup>
              </Card>
            </Col>
          </Row>
        </>
      )}
    </>
  )
}