import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { createOrder } from '../actions/orderActions'
import Loader from '../components/Loader'
import Message from '../components/Message'

export default function PlaceOrderScreen() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const orderCreate = useSelector((state) => state.orderCreate)
  const userLogin = useSelector((state) => state.userLogin)
  const { userInfo } = userLogin
  const { loading, success, error, order } = orderCreate
  const cart = useSelector((state) => state.cart)
  const { cartItems, shippingAddress, paymentMethod } = cart

  const priceItems = cartItems.reduce((a, c) => a + c.price * c.qty, 0)
  const priceTax = priceItems * 0.2
  const priceShipping = priceItems * 0.1
  const priceTotal = priceItems + priceTax + priceShipping

  useEffect(() => {
    if (!userInfo) {
      navigate('/login')
      return
    }
    const orderData = {
      order_items: cartItems.map((x) => ({
        product: x.product,
        name: x.name,
        qty: x.qty,
        price: x.price,
        image: x.image,
      })),
      shipping_address: {
        address: shippingAddress.address,
        city: shippingAddress.city,
        postal_code: shippingAddress.postalCode,
        country: shippingAddress.country,
      },
      payment_method: paymentMethod,
      items_price: priceItems,
      tax_price: priceTax,
      shipping_price: priceShipping,
      total_price: priceTotal,
    }
    dispatch(createOrder(orderData))
  }, [dispatch, cartItems, shippingAddress, paymentMethod, userInfo, navigate])

  useEffect(() => {
    if (success && order && order.id) {
      navigate('/order/confirmation', { state: { order } })
    }
  }, [success, order, navigate])

  return (
    <>
      {loading ? (
        <Loader />
      ) : error ? (
        <Message variant="danger">{error}</Message>
      ) : null}
    </>
  )
}