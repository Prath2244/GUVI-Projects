import React, { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { Row, Col, Form, Button, Card } from 'react-bootstrap'
import { login } from '../actions/userActions'
import Loader from '../components/Loader'
import Message from '../components/Message'

export default function LoginScreen() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  })

  const dispatch = useDispatch()
  const navigate = useNavigate()

  const userLogin = useSelector((state) => state.userLogin)
  const { loading, error, userInfo } = userLogin

  const submitHandler = (e) => {
    e.preventDefault()
    dispatch(login(formData.email, formData.password))
  }

  useEffect(() => {
    if (userInfo) {
      navigate('/order/confirmation')
    }
  }, [userInfo, navigate])

  return (
    <>
      {loading ? (
        <Loader />
      ) : error ? (
        <Message variant="danger">{error}</Message>
      ) : null}
      <Row start="xs">
        <Col md={4} className="m-4">
          <Card>
            <Card.Body className="text-center">
              <h3>Login</h3>
            </Card.Body>
            <Card.Body>
              <Form onSubmit={submitHandler}>
                <Form.Group>
                  <Form.Label>Email Address</Form.Label>
                  <Form.Control
                    type="email"
                    placeholder="Enter your email"
                    name="email"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({ ...formData, [e.target.name]: e.target.value })
                    }
                    required
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Password</Form.Label>
                  <Form.Control
                    type="password"
                    placeholder="Enter your password"
                    name="password"
                    value={formData.password}
                    onChange={(e) =>
                      setFormData({ ...formData, [e.target.name]: e.target.value })
                    }
                    required
                  />
                </Form.Group>
                <Button className="w-100" primary type="submit">
                  Login
                </Button>
              </Form>
            </Card.Body>
            <Card.Body className="text-center">
              {'Don\'t have an account? '}
              <a href="/register">Register</a>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </>
  )
}