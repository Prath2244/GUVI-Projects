import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <div className="text-center">
      <Link to="/" className="btn btn-primary">
        Home
      </Link>
    </div>
  )
}