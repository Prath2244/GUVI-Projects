import React, { useEffect } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { useSelector } from 'react-redux'

const formatPrice = (price) => (price != null ? Number(price).toFixed(2) : '0.00')

export default function OrderConfirmationScreen() {
  const navigate = useNavigate()
  const location = useLocation()
  const order = location.state?.order

  const userLogin = useSelector((state) => state.userLogin)
  const { userInfo } = userLogin

  useEffect(() => {
    if (!userInfo) {
      navigate('/login')
    }
  }, [userInfo, navigate])

  return (
    <div className="container my-5">
      <div className="card shadow-sm border-0 rounded-4 overflow-hidden">
        <div className="card-header bg-success text-white text-center py-4">
          <h2 className="mb-0">✅ Order Confirmed</h2>
        </div>
        <div className="card-body p-5">
          <div className="text-center mb-4">
            <h4 className="text-success">Thank you for your order!</h4>
            <p className="text-muted">
              Your order has been confirmed and will be delivered within <strong>3 working days</strong>.
            </p>
          </div>
          {order && order.id && (
            <>
              <hr />
              <div className="row mb-3">
                <div className="col-md-6">
                  <p className="fw-bold">Order ID:</p>
                  <p>{order.id}</p>
                </div>
                <div className="col-md-6">
                  <p className="fw-bold">Total:</p>
                  <p>Rs {formatPrice(order.total_price)}</p>
                </div>
              </div>
            </>
          )}
          <div className="text-center mt-4">
            <button className="btn btn-primary" onClick={() => navigate('/')}>
              Continue Shopping
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
