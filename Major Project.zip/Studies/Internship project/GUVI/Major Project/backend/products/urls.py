from django.urls import path
from . import views

urlpatterns = [
    path('products/', views.get_products, name='products'),
    path('product/<str:pk>/', views.get_product, name='product'),
    path('users/login/', views.MyTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('users/register/', views.register_user, name='register'),
    path('orders/add/', views.add_order_items, name='orders-add'),
    path('orders/myorders/', views.get_my_orders, name='my-orders'),
    path('orders/', views.get_orders, name='orders'),
    path('orders/<str:pk>/', views.get_order_by_id, name='user-order'),
    path('orders/<str:pk>/deliver/', views.update_order_to_delivered, name='order-delivered'),
    path('products/create/', views.create_product, name='product-create'),
    path('products/upload/', views.upload_image, name='image-upload'),
    path('products/<str:pk>/', views.update_product, name='product-update'),
    path('products/delete/<str:pk>/', views.delete_product, name='product-delete'),
    path('users/profile/', views.get_user_profile, name='user-profile'),
    path('users/profile/update/', views.update_user_profile, name='user-profile-update'),
]